import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.css']
})
export class DashboardComponent implements OnInit {
  students: any[] = [];
  avgGPA = '8.50';

  ngOnInit() {
    // Load from localStorage only - to avoid blank backend data
    const users = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
    this.students = users;
  }
}