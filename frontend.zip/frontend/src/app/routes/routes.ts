import { Routes } from '@angular/router';
import { LoginComponent } from '../login/login';
import { RegisterComponent } from '../register/register';
import { ForgotComponent } from '../forgot/forgot';
import { DashboardComponent } from '../dashboard/dashboard';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'forgot', component: ForgotComponent },
  { path: 'dashboard', component: DashboardComponent },
];