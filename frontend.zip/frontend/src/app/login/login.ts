import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class LoginComponent {
  constructor(private router: Router){}
  login(email:string, pass:string){
    if(!email||!pass){ alert('Enter Email & Password'); return; }
    const users = JSON.parse(localStorage.getItem('registeredUsers')||'[]');
    const found = users.find((u:any)=>u.email===email && u.password===pass);
    if(found){
      localStorage.setItem('currentUser', JSON.stringify(found));
      this.router.navigate(['/dashboard']);
    } else {
      alert('Wrong Email or Password!');
    }
  }
  goRegister(){ this.router.navigate(['/register']); }
  goForgot(){ this.router.navigate(['/forgot']); }
}