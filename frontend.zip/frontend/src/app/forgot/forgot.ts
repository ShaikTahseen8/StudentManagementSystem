import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
@Component({ selector: 'app-forgot', standalone: true, imports: [CommonModule], templateUrl: './forgot.html', styleUrl: './forgot.css' })
export class ForgotComponent {
  constructor(private router: Router){}
  reset(email:string, newPass:string){
    if(!email||!newPass){ alert('Fill all fields'); return; }
    let users = JSON.parse(localStorage.getItem('registeredUsers')||'[]');
    let index = users.findIndex((u:any)=>u.email===email);
    if(index===-1){ alert('Email not found'); return; }
    users[index].password = newPass;
    localStorage.setItem('registeredUsers', JSON.stringify(users));
    alert('Password Reset Success! Login Now');
    this.router.navigate(['/login']);
  }
  goLogin(){ this.router.navigate(['/login']); }
}