import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterModule],
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})
export class RegisterComponent {
  firstName = '';
  lastName = '';
  collegeId = '';
  email = '';
  course = 'Pharmacy';
  password = '';
  confirmPassword = '';

  constructor(private router: Router) {}

  onRegister() {
    const newUser = {
      name: this.firstName + ' ' + this.lastName,
      email: this.email,
      course: this.course,
      cgpa: '8.5',
      attendance: '85',
      status: 'Active'
    };
    let users = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
    users.push(newUser);
    localStorage.setItem('registeredUsers', JSON.stringify(users));
    this.router.navigate(['/dashboard']);
  }

  goLogin() {
    this.router.navigate(['/login']);
  }
}